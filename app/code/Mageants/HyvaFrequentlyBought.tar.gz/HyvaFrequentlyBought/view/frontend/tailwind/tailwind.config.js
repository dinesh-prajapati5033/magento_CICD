module.exports = {
    content: [
        '../templates/**/*.phtml',
    ]
}
