<?php
/**
 * Webkul Software
 *
 * @category Webkul
 * @package Webkul_MpMassPaypalPayment
 * @author Webkul
 * @copyright Copyright (c)  Webkul Software Private Limited (https://webkul.com)
 * @license https://store.webkul.com/license.html
 */
namespace Webkul\MpMassPaypalPayment\Api\Data;

use Magento\Framework\Api\SearchResultsInterface;

/**
 * Interface for seller paypal details search results.
 * @api
 */
interface PaypalConfigSearchResultsInterface extends SearchResultsInterface
{
    /**
     * Get preorder Complete list.
     *
     * @return \Webkul\MpMassPaypalPayment\Api\Data\PaypalConfigInterface[]
     */
    public function getItems();

    /**
     * Set preorder Complete list.
     *
     * @param \Webkul\MpMassPaypalPayment\Api\Data\PaypalConfigInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}
