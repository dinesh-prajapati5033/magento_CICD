<?php
/**
 * Webkul Software
 *
 * @category Webkul
 * @package Webkul_MpMassPaypalPayment
 * @author Webkul
 * @copyright Copyright (c)  Webkul Software Private Limited (https://webkul.com)
 * @license https://store.webkul.com/license.html
 */
namespace Webkul\MpMassPaypalPayment\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

/**
 * seller paypal details CRUD interface.
 * @api
 */
interface PaypalConfigRepositoryInterface
{
    /**
     * Save Seller Paypal Details.
     *
     * @param \Webkul\MpMassPaypalPayment\Api\Data\PaypalConfigInterface $items
     * @return \Webkul\MpMassPaypalPayment\Api\Data\PaypalConfigInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(Data\PaypalConfigInterface $items);

    /**
     * Retrieve Seller Paypal Details.
     *
     * @param int $id
     * @return \Webkul\MpMassPaypalPayment\Api\Data\PaypalConfigInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getById($id);

    /**
     * Retrieve Seller Paypal Details matching the specified criteria.
     *
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Webkul\MpMassPaypalPayment\Api\Data\PaypalConfigSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(\Magento\Framework\Api\SearchCriteriaInterface $searchCriteria);

    /**
     * Delete Seller Paypal Details.
     *
     * @param \Webkul\MpMassPaypalPayment\Api\Data\PaypalConfigInterface $item
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(Data\PaypalConfigInterface $item);

    /**
     * Delete Seller Paypal Details ID.
     *
     * @param int $id
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($id);
}
