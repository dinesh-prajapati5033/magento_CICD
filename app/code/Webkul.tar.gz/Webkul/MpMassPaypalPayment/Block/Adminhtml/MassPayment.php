<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_MpMassPaypalPayment
 * @author    Webkul
 * @copyright Copyright (c)  Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\MpMassPaypalPayment\Block\Adminhtml;

class MassPayment extends \Magento\Backend\Block\Template
{
    /**
     * @var \Magento\Framework\Data\FormFactory
     */
    protected $configProvider;

    /**
     * @param \Magento\Backend\Block\Template\Context                     $context
     * @param \Webkul\MpMassPaypalPayment\Model\MarketplaceConfigProvider $configProvider
     * @param array                                                       $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Webkul\MpMassPaypalPayment\Model\MarketplaceConfigProvider $configProvider,
        array $data = []
    ) {
        $this->configProvider = $configProvider;
        parent::__construct($context, $data);
    }

    /**
     * Get Seller Config Data
     *
     * @return array
     */
    public function getSellerDataConfig()
    {
        $configData = $this->configProvider->getConfig();
        return $configData;
    }
}
