<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_MpMassPaypalPayment
 * @author    Webkul
 * @copyright Copyright (c)  Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\MpMassPaypalPayment\Controller\Adminhtml\Payout;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

class Items extends Action
{
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;

    /**
     * @param Context       $context
     * @param PageFactory   $resultPageFactory
     */
    public function __construct(
        Context $context,
        \Webkul\MpMassPaypalPayment\Model\PaypalData\BatchPayoutDetailsFactory $payoutFactory,
        PageFactory $resultPageFactory
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
        $this->payoutFactory = $payoutFactory;
    }

    /**
     * Items page.
     *
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Webkul_MpMassPaypalPayment::masspayment');
        $payoutId = $this->getRequest()->getParam('payout_id');
        
        if ($payoutId) {
            $model = $this->payoutFactory->create()->load($payoutId);
            $resultPage->getConfig()->getTitle()->prepend((__('Payout ID#'). $model->getPayoutBatchId()));
        } else {
            $resultPage->getConfig()->getTitle()->prepend(__('Manage Sellers'));
        }
        
        return $resultPage;
    }

    /**
     * Check for is allowed.
     *
     * @return boolean
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Webkul_MpMassPaypalPayment::masspayment');
    }
}
