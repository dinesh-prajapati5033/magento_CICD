<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_MpMassPaypalPayment
 * @author    Webkul
 * @copyright Copyright (c)  Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\MpMassPaypalPayment\Controller\Adminhtml\Paypal;

use Magento\Backend\App\Action\Context;
use Webkul\MpMassPaypalPayment\Model\BatchPayoutFactory;
use PayPal\Exception\PayPalConnectionException;
use Webkul\MpMassPaypalPayment\Api\Data\BatchPayoutDetailsInterfaceFactory;

/**
 * Class MassPayment.
 * Mass Payments
 */
class MassPayment extends \Magento\Backend\App\Action
{
    /**
     * @var BatchPayoutFactory
     */
    protected $batchPayoutFactory;

    /**
     * @var \Webkul\MpMassPaypalPayment\Model\PaypalDataManagement
     */
    public $payPalDataManagement;

    /**
     * @var \Magento\Framework\Json\Helper\Data
     */
    protected $helper;

    /**
     * @var \Magento\Backend\Model\View\Result\RedirectFactory
     */
    protected $resultRedirect;

    /**
     * @var BatchPayoutDetailsInterfaceFactory
     */
    protected $payoutDatailsFactory;

    /**
     * @param Context $context
     * @param \Magento\Framework\Json\Helper\Data $helper
     * @param \Webkul\MpMassPaypalPayment\Model\PaypalDataManagement $payPalDataManagement
     * @param BatchPayoutFactory $batchPayoutFactory
     */
    public function __construct(
        Context $context,
        \Magento\Framework\Json\Helper\Data $helper,
        \Webkul\MpMassPaypalPayment\Model\PaypalDataManagement $payPalDataManagement,
        BatchPayoutFactory $batchPayoutFactory,
        BatchPayoutDetailsInterfaceFactory $payoutDatailsFactory
    ) {
        parent::__construct($context);
        $this->helper = $helper;
        $this->batchPayoutFactory = $batchPayoutFactory;
        $this->payPalDataManagement = $payPalDataManagement;
        $this->resultRedirect = $context->getResultRedirectFactory();
        $this->payoutDatailsFactory = $payoutDatailsFactory;
    }

    /**
     * Execute action.
     *
     * @return \Magento\Backend\Model\View\Result\Redirect
     *
     * @throws \Magento\Framework\Exception\LocalizedException|\Exception
     */
    public function execute()
    {
        $data = $this->getRequest()->getParam('seller_data');
        $data['data'] = $this->helper->jsonDecode($data['data']);
        $sellerWithOrderId = [];
        foreach ($data['data'] as $row) {
            if (isset($row['order_ids'])) {
                $sellerWithOrderId[] = $row['seller_id'].':'.$row['order_ids'];
            }
        }
        $sellerWithOrderIdString = implode('_', $sellerWithOrderId);
        
        if ($this->payPalDataManagement->getPaymentsCompletedStatus()) {
            $this->messageManager->addNotice(__('Your previous payment(s) in PENDING state, please wait.'));
            return $this->resultRedirect->create()->setPath('marketplace/seller/');
        }
        if (empty($data['data'])) {
            $this->messageManager->addError(__('Payment data is empty.'));
            return $this->resultRedirect->create()->setPath('marketplace/seller/');
        }
        $defalters = '';
        foreach ($data['data'] as $key => $value) {
            if ($value['base_amount'] <= 0) {
                unset($data['data'][$key]);
            }
            if ($value['seller_email'] == "N/A") {
                $defalters .= $value['seller_name'].', ';
                unset($data['data'][$key]);
            }
        }

        if ($defalters) {
            $this->messageManager->addError(__('Seller %1 has not saved his Paypal details.', $defalters));
        }

        if (empty($data['data'])) {
            $this->messageManager->addError(__('No Seller is pending for payment.'));
            return $this->resultRedirect->create()->setPath('marketplace/seller/');
        }
        $count = count($data['data']);
        try {
            $response = $this->batchPayoutFactory->create()
                ->createBatchPayment($data);
            
            if ($response instanceof \PayPal\Api\PayoutBatch) {
                $this->messageManager->addSuccess(__('Mass Payment Processed Sucessfully for %1 Seller(s).', $count));
                $this->messageManager->addNotice(__('Wait for this payment to complete before processing another.
                For more details, view transaction history.'));
                $result = $this->payPalDataManagement->savePayoutData($response);
                if ($result) {
                    if ($sellerWithOrderIdString) {
                        $payoutData = $this->payoutDatailsFactory->create()->load($result);
                        $payoutData->setOrdersId($sellerWithOrderIdString);
                        $payoutData->save();
                    }
                }
            }
        } catch (PayPalConnectionException $e) {
            $message = $e->getMessage();
            $response = json_decode($e->getData());

            if (json_last_error() === JSON_ERROR_NONE) {
                if (isset($response->message)) {
                    $message = $response->message;
                } elseif (isset($response->error_description)) {
                    $message = $response->error_description;
                }
            }
            $this->messageManager->addError($message);
        } catch (\Exception $e) {
            $this->messageManager->addError($e->getMessage());
        }
        return $this->resultRedirect->create()->setPath('marketplace/seller/');
    }

    /**
     * Check for is allowed.
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Webkul_MpMassPaypalPayment::masspayment');
    }
}
