<?php
/**
 * Webkul Software.
 *
 * @category   Webkul
 * @package    Webkul_MpMassPaypalPayment
 * @author     Webkul Software Private Limited
 * @copyright  Copyright (c)  Webkul Software Private Limited (https://webkul.com)
 * @license    https://store.webkul.com/license.html
 */
namespace Webkul\MpMassPaypalPayment\Cron;

use Webkul\MpMassPaypalPayment\Api\Data\BatchPayoutDetailsInterfaceFactory;
use Webkul\MpMassPaypalPayment\Model\PaypalDataManagement;

class FetchPaymentStatus
{
    /**
     *
     * @var BatchPayoutDetailsInterfaceFactory
     */
    protected $papalDataManagement;

    /**
     *
     * @var \Webkul\MpMassPaypalPayment\Model\PaypalDataManagement
     */
    protected $payoutDatailsFactory;

    /**
     * Update Payment
     *
     * @param BatchPayoutDetailsInterfaceFactory $payoutDatailsFactory
     * @param \Webkul\MpMassPaypalPayment\Model\PaypalDataManagement $papalDataManagement
     */
    public function __construct(
        BatchPayoutDetailsInterfaceFactory $payoutDatailsFactory,
        \Webkul\MpMassPaypalPayment\Model\PaypalDataManagement $papalDataManagement
    ) {
        $this->papalDataManagement = $papalDataManagement;
        $this->payoutDatailsFactory = $payoutDatailsFactory;
    }

    /**
     * Start execution
     *
     */
    public function execute()
    {
        $collection = $this->payoutDatailsFactory->create()
            ->getCollection('batch_status', ['eq' => PaypalDataManagement::TRANSACTION_PENDING]);
        if ($collection->getSize()) {
            foreach ($collection as $batchDetailsModel) {
                $result =  $this->papalDataManagement->savePayoutItemsData(
                    $batchDetailsModel->getId(),
                    $batchDetailsModel->getPayoutBatchId()
                );
                if ($result) {
                    $batchDetailsModel->setBatchStatus(PaypalDataManagement::TRANSACTION_SUCCESS);
                    $batchDetailsModel->save();
                }
            }
        }
    }
}
