<?php
/**
 * Webkul Software.
 *
 * @category   Webkul
 * @package    Webkul_MpMassPaypalPayment
 * @author     Webkul Software Private Limited
 * @copyright  Copyright (c)  Webkul Software Private Limited (https://webkul.com)
 * @license    https://store.webkul.com/license.html
 */
namespace Webkul\MpMassPaypalPayment\Helper;

/**
 * MpMassPaypalPayment data helper.
 */
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     * @var \Webkul\MpMassPaypalPayment\Model\PaypalConfigFactory
     */
    private $paypalConfigFactory;

    /**
     * @param \Magento\Framework\App\Helper\Context $context
     * @param \Webkul\MpMassPaypalPayment\Model\PaypalConfigFactory $paypalConfigFactory
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Webkul\MpMassPaypalPayment\Model\PaypalConfigFactory $paypalConfigFactory
    ) {
        $this->paypalConfigFactory = $paypalConfigFactory;
        parent::__construct($context);
    }

    /**
     * Retrieve information from carrier configuration.
     *
     * @param string $field
     *
     * @return void|false|string
     */
    public function getConfigData($field)
    {
        $path = 'marketplace/mass_payment/'.$field;
        return $this->scopeConfig->getValue(
            $path,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * @param int $paypalId
     * @param int $customerId
     * @return bool
     */
    public function checkPaypalIdExistsOrNot($paypalId, $customerId)
    {
        $paypalidexist = $this->paypalConfigFactory->create()->getCollection()
        ->addFieldToFilter(
            'paypal_id',
            $paypalId
        )->addFieldToFilter(
            'seller_id',
            ['neq' => $customerId]
        );
        if (!empty($paypalidexist)) {
            foreach ($paypalidexist as $paypalid) {
                if ($paypalid->getPaypalId()) {
                    return true;
                }
            }
        } else {
            return false;
        }
    }
}
