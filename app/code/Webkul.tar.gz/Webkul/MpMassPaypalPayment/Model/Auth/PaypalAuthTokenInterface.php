<?php
/**
 * Webkul Software.
 *
 * @category   Webkul
 * @package    Webkul_MpMassPaypalPayment
 * @author     Webkul Software Private Limited
 * @copyright  Copyright (c)  Webkul Software Private Limited (https://webkul.com)
 * @license    https://store.webkul.com/license.html
 */
namespace Webkul\MpMassPaypalPayment\Model\Auth;

/**
 * Interface \Webkul\MpMassPaypalPayment\Model\Auth\PaypalAuthTokenInterface
 *
 */
interface PaypalAuthTokenInterface
{
    /**
     * @var string
     */
    const CLIENT_ID_PATH = 'marketplace/mass_payment/client_id';
    const SECRET_ID_PATH = 'marketplace/mass_payment/secret_id';
    const MODE           = 'marketplace/mass_payment/sandbox';
    
    /**
     * @return \PayPal\Rest\ApiContext
     */
    public function getApiContext();
}
