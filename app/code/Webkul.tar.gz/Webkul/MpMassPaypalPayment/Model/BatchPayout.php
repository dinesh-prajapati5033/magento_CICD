<?php
/**
 * Webkul Software.
 *
 * @category   Webkul
 * @package    Webkul_MpMassPaypalPayment
 * @author     Webkul Software Private Limited
 * @copyright  Copyright (c)  Webkul Software Private Limited (https://webkul.com)
 * @license    https://store.webkul.com/license.html
 */
namespace Webkul\MpMassPaypalPayment\Model;

use PayPal\Exception\PayPalConnectionException;

class BatchPayout extends AbstractPaypalBatchPayout
{
    /**
     * Create Mass Payment Api Request
     *
     * @param array $request
     * @return \PayPal\Api\PayoutBatch|Exception
     */
    public function createBatchPayment($request)
    {
        $payouts = $this->getBatchPayout($request);
        $apiContext = $this->authTokenFactory->create()->getApiContext();
        $output = null;
        try {
            $output = $payouts->create(null, $apiContext);
            $payoutBatchId = $output->getBatchHeader()->getPayoutBatchId();
            if ($payoutBatchId) {
                return $output;
            } else {
                throw new \Magento\Framework\Exception\StateException(
                    __('Payment can not be process.')
                );
            }
        } catch (PayPalConnectionException $ex) {
            $this->logger->info($ex->getMessage()."[" . __LINE__ . "]");
            throw $ex;
        } catch (Exception $ex) {
            $this->logger->info($ex->getMessage()."[" . __LINE__ . "]");
            throw new \Magento\Framework\Exception\StateException(
                __($ex->getMessage())
            );
            
        }
        return $output;
    }

    /**
     * Api Request to get Batch Payout Details
     *
     * @param string $payoutId
     * @return \PayPal\Api\PayoutBatch|Exception
     */
    public function getPayoutDetails($payoutId)
    {
        try {
            $apiContext = $this->authTokenFactory->create()->getApiContext();
            $output = \PayPal\Api\Payout::get($payoutId, $apiContext);
            return $output;
        } catch (PayPalConnectionException $e) {
            $this->logger->error($e->getMessage()."[" . __LINE__ . "]");
            throw $e;
        } catch (\Exception $e) {
            $this->logger->info($e->getMessage()."[" . __LINE__ . "]");
            throw new \Magento\Framework\Exception\StateException(
                __($e->getMessage())
            );
        }
    }

    /**
     * Api Request to get Batch Payout item Details
     *
     * @param string $payoutId
     * @return \PayPal\Api\PayoutItemDetails|Exception
     */
    public function getPayoutItemDetails($itemId)
    {
        try {
            $apiContext = $this->authTokenFactory->create()->getApiContext();
            $output = \PayPal\Api\PayoutItem::get($itemId, $apiContext);
            return $output;
        } catch (PayPalConnectionException $e) {
            $this->logger->error($e->getMessage()."[" . __LINE__ . "]");
            throw $e;
        } catch (\Exception $e) {
            $this->logger->info($e->getMessage()."[" . __LINE__ . "]");
            throw new \Magento\Framework\Exception\StateException(
                __($e->getMessage())
            );
        }
    }

    /**
     * Api Request to cancel unclaimed payment
     *
     * @param string $payoutId
     * @return \PayPal\Api\PayoutItemDetails|Exception
     */
    public function cancelPayment($itemId)
    {
        try {
            $apiContext = $this->authTokenFactory->create()->getApiContext();
            $output = \PayPal\Api\PayoutItem::cancel($itemId, $apiContext);
            return $output;
        } catch (PayPalConnectionException $e) {
            $this->logger->error($e->getMessage()."[" . __LINE__ . "]");
            throw $e;
        } catch (\Exception $e) {
            $this->logger->info($e->getMessage()."[" . __LINE__ . "]");
            throw $e;
        }
    }
}
