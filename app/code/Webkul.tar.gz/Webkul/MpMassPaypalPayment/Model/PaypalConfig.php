<?php
/**
 * Webkul Software
 *
 * @category Webkul
 * @package Webkul_MpMassPaypalPayment
 * @author Webkul
 * @copyright Copyright (c)  Webkul Software Private Limited (https://webkul.com)
 * @license https://store.webkul.com/license.html
 */
namespace Webkul\MpMassPaypalPayment\Model;

use Webkul\MpMassPaypalPayment\Api\Data\PaypalConfigInterface;
use Webkul\MpMassPaypalPayment\Model\ResourceModel\PaypalConfig as ResourcePaypalConfig;
use Magento\Framework\DataObject\IdentityInterface;
use Magento\Framework\Model\AbstractModel;

/**
 * Proerder Complete Item Model
 *
 */
class PaypalConfig extends AbstractModel implements PaypalConfigInterface, IdentityInterface
{
    /**
     * Proerder Item cache tag
     */
    const CACHE_TAG = 'paypal_config';

    /**#@-*/
    /**
     * @var string
     */
    protected $_cacheTag = 'paypal_config';

    /**
     * Prefix of model events names
     *
     * @var string
     */
    protected $_eventPrefix = 'paypal_config';

    /**
     * @return void
     */
    protected function _construct()
    {
        $this->_init(
            \Webkul\MpMassPaypalPayment\Model\ResourceModel\PaypalConfig::class
        );
    }

    /**
     * Get identities
     *
     * @return array
     */
    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId(), self::CACHE_TAG . '_' . $this->getIdentifier()];
    }

    /**
     * Get ID
     *
     * @return int|null
     */
    public function getId()
    {
        return $this->getData(self::ENTITY_ID);
    }

    /**
     * Get Seller ID
     *
     * @return int|null
     */
    public function getSellerId()
    {
        return $this->getData(self::SELLER_ID);
    }

    /**
     * Get paypal email Id
     *
     * @return int|null
     */
    public function getPaypalId()
    {
        return $this->getData(self::PAYPAL_ID);
    }

    /**
     * Get paypal first name
     *
     * @return string
     */
    public function getPaypalFname()
    {
        return $this->getData(self::PAYPAL_FNAME);
    }

    /**
     * Get paypal last name
     *
     * @return string
     */
    public function getPaypalLname()
    {
        return $this->getData(self::PAYPAL_LNAME);
    }

    /**
     * Get created at
     *
     * @return string
     */
    public function getCreatedAt()
    {
        return $this->getData(self::CREATED_AT);
    }

    /**
     * Get updated at
     *
     * @return string
     */
    public function getUpdatedAt()
    {
        return $this->getData(self::UPDATED_AT);
    }

    /**
     * Set ID
     */
    public function setId($id)
    {
        $this->setData(self::ENTITY_ID, $id);
    }

    /**
     * Set Order Item ID
     */
    public function setSellerId($sellerId)
    {
        $this->setData(self::SELLER_ID, $sellerId);
    }

    /**
     * Set paypal email ID
     */
    public function setPaypalId($paypalId)
    {
        $this->setData(self::PAYPAL_ID, $paypalId);
    }

    /**
     * Set paypal first name
     */
    public function setPaypalFname($fname)
    {
        $this->setData(self::PAYPAL_FNAME, $fname);
    }

    /**
     * Set paypal last name
     */
    public function setPaypalLname($lname)
    {
        $this->setData(self::PAYPAL_LNAME, $lname);
    }

    /**
     * Set created date
     */
    public function setCreatedAt($date)
    {
        $this->setData(self::CREATED_AT, $date);
    }

    /**
     * Set updated date
     */
    public function setUpdatedAt($date)
    {
        $this->setData(self::UPDATED_AT, $date);
    }
}
