<?php
/**
 * Webkul Software
 *
 * @category Webkul
 * @package Webkul_MpMassPaypalPayment
 * @author Webkul
 * @copyright Copyright (c)  Webkul Software Private Limited (https://webkul.com)
 * @license https://store.webkul.com/license.html
 */
namespace Webkul\MpMassPaypalPayment\Model;

use Webkul\MpMassPaypalPayment\Api\Data;
use Webkul\MpMassPaypalPayment\Api\PaypalConfigRepositoryInterface;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\SortOrder;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Webkul\MpMassPaypalPayment\Model\ResourceModel\PaypalConfig as ResourcePaypalConfig;
use Webkul\MpMassPaypalPayment\Model\ResourceModel\PaypalConfig\CollectionFactory as PaypalConfigCollectionFactory;

class PaypalConfigRepository implements PaypalConfigRepositoryInterface
{
    /**
     * @var ResourceBlock
     */
    protected $resource;

    /**
     * @var BlockFactory
     */
    protected $paypalConfigFactory;

    /**
     * @var BlockCollectionFactory
     */
    protected $paypalConfigCollectionFactory;

    /**
     * @var Data\BlockSearchResultsInterfaceFactory
     */
    protected $searchResultsFactory;

    /**
     * @var DataObjectHelper
     */
    protected $dataObjectHelper;

    /**
     * @var DataObjectProcessor
     */
    protected $dataObjectProcessor;

    /**
     * @var \Magento\Cms\Api\Data\BlockInterfaceFactory
     */
    protected $dataPaypalConfigFactory;

    /**
     * @param ResourcePaypalConfig $resource
     * @param PaypalConfigFactory $paypalConfigFactory
     * @param Data\PreorderCompleteInterfaceFactory $dataPaypalConfigFactory
     * @param PaypalConfigCollectionFactory $paypalConfigCollectionFactory
     * @param Data\PreorderCompleteSearchResultsInterfaceFactory $searchResultsFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     */
    public function __construct(
        ResourcePaypalConfig $resource,
        PaypalConfigFactory $paypalConfigFactory,
        \Webkul\MpMassPaypalPayment\Api\Data\PaypalConfigInterfaceFactory $dataPaypalConfigFactory,
        PaypalConfigCollectionFactory $paypalConfigCollectionFactory,
        Data\PaypalConfigSearchResultsInterfaceFactory $searchResultsFactory,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor
    ) {
        $this->resource = $resource;
        $this->paypalConfigFactory = $paypalConfigFactory;
        $this->paypalConfigCollectionFactory = $paypalConfigCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataPaypalConfigFactory = $dataPaypalConfigFactory;
        $this->dataObjectProcessor = $dataObjectProcessor;
    }

    /**
     * Save seller paypal data
     *
     * @param \Webkul\MarketplacePreorder\Api\Data\PaypalConfigInterface $paypalConfig
     * @return PreorderComplete
     * @throws CouldNotSaveException
     */
    public function save(Data\PaypalConfigInterface $paypalConfig)
    {
        try {
            $this->resource->save($paypalConfig);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__($exception->getMessage()));
        }
        return $paypalConfig;
    }

    /**
     * Load seller paypal data by given Identity
     *
     * @param string $id
     * @return PreorderComplete
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getById($id)
    {
        $paypalConfig = $this->paypalConfigFactory->create();
        $this->resource->load($paypalConfig, $id);
        if (!$paypalConfig->getEntityId()) {
            throw new NoSuchEntityException(__('Paypal details with id "%1" does not exist.', $id));
        }
        return $paypalConfig;
    }

    /**
     * {inherited}
     */
    public function getList(\Magento\Framework\Api\SearchCriteriaInterface $criteria)
    {
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);

        $collection = $this->paypalConfigCollectionFactory->create();
        foreach ($criteria->getFilterGroups() as $filterGroup) {
            foreach ($filterGroup->getFilters() as $filter) {
                $condition = $filter->getConditionType() ?: 'eq';
                $collection->addFieldToFilter($filter->getField(), [$condition => $filter->getValue()]);
            }
        }
        $searchResults->setTotalCount($collection->getSize());
        $sortOrders = $criteria->getSortOrders();
        if ($sortOrders) {
            foreach ($sortOrders as $sortOrder) {
                $collection->addOrder(
                    $sortOrder->getField(),
                    ($sortOrder->getDirection() == SortOrder::SORT_ASC) ? 'ASC' : 'DESC'
                );
            }
        }
        $collection->setCurPage($criteria->getCurrentPage());
        $collection->setPageSize($criteria->getPageSize());
        $paypalConfigData = [];
        /** @var PreorderComplete $paypalConfigData */
        foreach ($collection as $paypalConfigDataModel) {
            $paypalConfig = $this->dataPaypalConfigFactory->create();
            $this->dataObjectHelper->populateWithArray(
                $paypalConfig,
                $paypalConfigData->getData(),
                \Webkul\MpMassPaypalPayment\Api\Data\PaypalConfigInterface::class
            );
            $paypalConfigData[] = $this->dataObjectProcessor->buildOutputDataArray(
                $paypalConfig,
                \Webkul\MpMassPaypalPayment\Api\Data\PaypalConfigInterface::class
            );
        }
        $searchResults->setItems($paypalConfigData);
        return $searchResults;
    }

    /**
     * Delete PreorderComplete
     *
     * @param \Webkul\MarketplacePreorder\Api\Data\PreorderCompleteInterface $paypalConfig
     * @return bool
     * @throws CouldNotDeleteException
     */
    public function delete(Data\PaypalConfigInterface $paypalConfig)
    {
        try {
            $this->resource->delete($paypalConfig);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__($exception->getMessage()));
        }
        return true;
    }

    /**
     * Delete PreorderComplete by given Block Identity
     *
     * @param string $id
     * @return bool
     * @throws CouldNotDeleteException
     * @throws NoSuchEntityException
     */
    public function deleteById($id)
    {
        return $this->delete($this->getById($id));
    }
}
