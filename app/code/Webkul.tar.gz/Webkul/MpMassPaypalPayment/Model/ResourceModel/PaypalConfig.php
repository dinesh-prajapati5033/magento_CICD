<?php
/**
 * Webkul Software.
 *
 * @category   Webkul
 * @package    Webkul_MpMassPaypalPayment
 * @author     Webkul Software Private Limited
 * @copyright  Copyright (c)  Webkul Software Private Limited (https://webkul.com)
 * @license    https://store.webkul.com/license.html
 */
namespace Webkul\MpMassPaypalPayment\Model\ResourceModel;

class PaypalConfig extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('marketplace_mpadaptivepayment', 'entity_id');
    }
}
