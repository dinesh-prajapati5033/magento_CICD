<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_MpMassPaypalPayment
 * @author    Webkul
 * @copyright Copyright (c)  Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\MpMassPaypalPayment\Ui\Component\Listing\Columns;

use Magento\Framework\UrlInterface;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Ui\Component\Listing\Columns\Column;

/**
 * Class CancelPaymentLink.
 * Prepare DataSource
 */
class CancelPaymentLink extends Column
{
    /**
     * @var UrlInterface
     */
    protected $urlBuilder;

    /**
     * Constructor.
     *
     * @param ContextInterface   $context
     * @param UiComponentFactory $uiComponentFactory
     * @param UrlInterface       $urlBuilder
     * @param array              $components
     * @param array              $data
     */
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        UrlInterface $urlBuilder,
        array $components = [],
        array $data = []
    ) {
        $this->urlBuilder = $urlBuilder;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    /**
     * Prepare Data Source.
     *
     * @param array $dataSource
     *
     * @return array
     */
    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            $fieldName = $this->getData('name');
            foreach ($dataSource['data']['items'] as &$item) {
                $item[$fieldName.'_flag'] = 0;
                
                $url = $this->urlBuilder
                    ->getUrl('mpmasspay/payout/cancelpayment', ['item_id' => $item['payout_item_id']]);
                if (($item['transaction_status'] ==
                \Webkul\MpMassPaypalPayment\Model\PaypalDataManagement::TRANSACTION_UNCLAIMED)) {
                    $item[$fieldName.'_flag'] = 1;
                    $item[$fieldName.'_html'] =
                    '<button type="button" class="button wk_payseller" auto-id="'
                    .$item['entity_id'].'" title="'.__('Cancel Payment').'"><span><span><span>'
                    .__('Cancel Payment').'</span></span></span></button>';
                } elseif (($item['transaction_status'] ==
                \Webkul\MpMassPaypalPayment\Model\PaypalDataManagement::TRANSACTION_SUCCESS)) {
                    $item[$fieldName.'_flag'] = 0;
                    $item[$fieldName.'_html'] = '<span>Payment Success</span>';
                }
                $item[$fieldName.'_title'] = __('Unclaimed Payment');
                $item[$fieldName.'_submitlabel'] = __('Cancel Payment');
                $item[$fieldName.'_url'] = __($url);
                $item[$fieldName.'_content'] =
                __('You can cancel an unclaimed transaction. 
                If no one claims the unclaimed item within 30 days, 
                the funds are automatically returned to the sender.');
            }
        }

        return $dataSource;
    }
}
