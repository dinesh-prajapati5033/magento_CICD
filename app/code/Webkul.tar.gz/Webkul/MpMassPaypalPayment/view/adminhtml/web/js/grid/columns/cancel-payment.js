/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_MpMassPaypalPayment
 * @author    Webkul
 * @copyright Copyright (c)  Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
define([
    'Magento_Ui/js/grid/columns/column',
    'jquery',
    'mage/template',
    'Magento_Ui/js/modal/confirm',
    'Magento_Ui/js/modal/modal'
], function (Column, $, mageTemplate, confirm) {
    'use strict';

    return Column.extend({
        defaults: {
            bodyTmpl: 'ui/grid/cells/html',
            fieldClass: {
                'data-grid-html-cell': true
            }
        },
        getFlag: function (row) {
            return row[this.index + '_flag'];
        },
        gethtml: function (row) {
            return row[this.index + '_html'];
        },
        getLabel: function (row) {
            return row[this.index + '_html']
        },
        getContent: function (row) {
            return row[this.index + '_content']
        },
        getTitle: function (row) {
            return row[this.index + '_title']
        },
        getUrl: function (row) {
            return row[this.index + '_url'];
        },
        preview: function (row) {
            var self = this;
            if (this.getFlag(row) == 1) {
                confirm({
                    title: this.getTitle(row),
                    content: this.getContent(row),
                    actions: {
                        confirm: function () {
                            window.location.replace(self.getUrl(row));
                        },
                        cancel: function () { },
                        always: function () { }
                    }
                });
            }
        },
        getFieldHandler: function (row) {
            return this.preview.bind(this, row);
        }
    });
});
