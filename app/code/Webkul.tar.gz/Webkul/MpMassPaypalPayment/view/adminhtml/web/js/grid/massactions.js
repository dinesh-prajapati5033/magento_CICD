/**
 * Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

define([
    'underscore',
    'uiRegistry',
    'mageUtils',
    'Magento_Ui/js/lib/collapsible',
    'Magento_Ui/js/modal/confirm',
    'Magento_Ui/js/modal/alert',
    'mage/translate',
    'jquery'
], function (_, registry, utils, Collapsible, confirm, alert, $t, $) {
    'use strict';

    return Collapsible.extend({
        defaults: {
            template: 'ui/grid/actions',
            stickyTmpl: 'ui/grid/sticky/actions',
            selectProvider: 'ns = ${ $.ns }, index = ids',
            actions: [],
            noItemsMsg: $t('You haven\'t selected any seller!'),
            massPaymentMsg: $t('Only 250 sellers are allowed to pay at once!'),
            modules: {
                selections: '${ $.selectProvider }'
            }
        },

        /**
         * Initializes observable properties.
         *
         * @returns {Massactions} Chainable.
         */
        initObservable: function () {

            this._super()
                .observe('actions');

            $('body').delegate('.action-accept', 'click', function () {
                jQuery('body').loader('show');
            });

            return this;
        },

        /**
         * Applies specified action.
         *
         * @param {String} actionIndex - Actions' identifier.
         * @returns {Massactions} Chainable.
         */
        applyAction: function (actionIndex) {
            var data = this.getSelections(),
                action,
                callback;

            if (!data.total) {
                alert({
                    content: this.noItemsMsg,
                    buttons: [{
                        text: $.mage.__('OK'),
                        class: 'action-primary'
                    }]
                });

                return this;
            }

            action = this.getAction(actionIndex);
            if (data.total > 250 && action.type == 'paypal_payment') {
                alert({
                    content: this.massPaymentMsg
                });

                return this;
            }
            callback = this._getCallback(action, data);
            if (action.type == 'paypal_payment') {
                action.confirm ?
                    this._paymentConfirm(action, callback) :
                    callback();
            } else {
                action.confirm ?
                    this._confirm(action, callback) :
                    callback();
            }

            return this;
        },

        /**
         * Retrieves selections data from the selections provider.
         *
         * @returns {Object|Undefined}
         */
        getSelections: function () {
            var provider = this.selections(),
                selections = provider && provider.getSelections();

            return selections;
        },

        /**
         * Retrieves action object associated with a specified index.
         *
         * @param {String} actionIndex - Actions' identifier.
         * @returns {Object} Action object.
         */
        getAction: function (actionIndex) {
            return _.findWhere(this.actions(), {
                type: actionIndex
            });
        },

        /**
         * Adds new action. If action with a specfied identifier
         * already exists, than the original one will be overrided.
         *
         * @param {Object} action - Action object.
         * @returns {Massactions} Chainable.
         */
        addAction: function (action) {
            var actions = this.actions(),
                index = _.findIndex(actions, {
                    type: action.type
                });

            ~index ?
                actions[index] = action :
                actions.push(action);

            this.actions(actions);

            return this;
        },

        /**
         * Creates action callback based on its' data. If action doesn't spicify
         * a callback function than the default one will be used.
         *
         * @private
         * @param {Object} action - Actions' object.
         * @param {Object} selections - Selections data.
         * @returns {Function} Callback function.
         */
        _getCallback: function (action, selections) {
            var callback = action.callback,
                args = [action, selections];

            if (utils.isObject(callback)) {
                args.unshift(callback.target);

                callback = registry.async(callback.provider);
            } else if (typeof callback != 'function') {
                callback = this.defaultCallback.bind(this);
            }

            return function () {
                callback.apply(null, args);
            };
        },

        /**
         * Default action callback. Sends selections data
         * via POST request.
         *
         * @param {Object} action - Action data.
         * @param {Object} data - Selections data.
         */
        defaultCallback: function (action, data) {
            var itemsType = data.excludeMode ? 'excluded' : 'selected',
                selections = {};

            selections[itemsType] = data[itemsType];

            if (!selections[itemsType].length) {
                selections[itemsType] = false;
            }

            _.extend(selections, data.params || {});

            utils.submit({
                url: action.url,
                data: selections
            });
        },

        /**
         * Shows actions' confirmation window.
         *
         * @param {Object} action - Actions' data.
         * @param {Function} callback - Callback that will be
         *      invoked if action is confirmed.
         */
        _confirm: function (action, callback) {
            var confirmData = action.confirm;

            confirm({
                title: confirmData.title,
                content: confirmData.message,
                actions: {
                    confirm: callback
                }
            });
        },
        _paymentConfirm: function (action, callback) {
            var confirmData = action.confirm;
            var selectedIds = this.getSelections();
            var disable = '';
            if (window.paypalDataConfig.paymentAvailable == 0) {
                disable = 'disabled';
            }

            var currencies = window.paypalDataConfig.currencies.split(",");
            var selectedData = [];
            var cCode = '';
            var content = '<tbody>';
            if (window.paypalDataConfig.sellerData.length) {
                $.each(window.paypalDataConfig.sellerData, function (i, v) {
                    $.each(selectedIds.selected, function (index, id) {
                        if (id == v.id) {
                            var customNote = '',
                                disabled = '';
                            if (v.base_amount <= 0) {
                                disabled = 'disabled';
                            }
                            customNote += '<td><input type="text" class="input-text admin__control-text" name="seller_data[custom_note][' + id + ']" ' + disabled + ' /></td>';
                            selectedData.push(v);
                            content += '<tr><td>' + v.seller_name + '</td><td>' + v.seller_email + '</td><td>' + v.amount + '</td>' + customNote + '</tr>';
                        }
                    });
                });
            }
            content += '</tbody>';

            confirm({
                title: confirmData.title,
                content: "<form class='masspaypal_form' style='overflow:auto' action='" + window.paypalDataConfig.paypalAction + "'><table class=\"data-grid\"><thead><tr><th class=\"data-grid-th\">" + $t('Seller Name') + "</th><th class=\"data-grid-th\">" + $t('Paypal Email') + "</th><th class=\"data-grid-th\">" + $t('Amount') + "</th><th class=\"data-grid-th\">" + $t('Payment Note') + "</th></tr></thead>" + content + "</table><input type=\"hidden\" name=\"seller_data[data]\" value='" + JSON.stringify(selectedData) + "'/><button style=\"float:right;margin-top:20px; margin-bottom:20px;\" class=\"action-primary action-accept\" type=\"submit\" data-role=\"closeBtn\" " + disable + "><span>" + $t('Pay') + "</span></button></form>",
                actions: {
                    confirm: callback
                },
                buttons: []
            });
            
            $('.masspaypal_form').parent().parent().parent().css("maxWidth", '60rem');
        }
    });
});